<?php
namespace Jeeb;

class Merchant {}
