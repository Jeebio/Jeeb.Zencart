<?php

define('MODULE_PAYMENT_JEEB_TEXT_TITLE', 'Bitcoin (powered by Jeeb)');
define('MODULE_PAYMENT_JEEB_TEXT_DESCRIPTION', 'Accept Bitcoin with Jeeb.');
define('MODULE_PAYMENT_JEEB_TEXT_CHECKOUT', 'Bitcoin');
